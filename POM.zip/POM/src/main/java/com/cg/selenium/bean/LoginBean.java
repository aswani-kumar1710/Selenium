package com.cg.selenium.bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginBean 
{
	
	@FindBy(how=How.NAME,name="username")
	private WebElement username;
	
	@FindBy(how=How.NAME,name="password")
	private WebElement password;
	
	@FindBy(how=How.NAME,name="submit")
	private WebElement submit;
	
	@FindBy(how=How.NAME,name="cancel")
	private WebElement cancel;

	public void setUserName(String userName)
	{
		this.username.sendKeys(userName);
	}
	
	public String getUserName()
	{
		return this.username.getAttribute("value");
	}
	public void setPassWord(String passWord)
	{
		this.password.sendKeys(passWord);
	}
	
	public String getPassWord()
	{
		return this.password.getAttribute("value");
	}
	public void submit(){

        this.submit.click();

}
	
}
