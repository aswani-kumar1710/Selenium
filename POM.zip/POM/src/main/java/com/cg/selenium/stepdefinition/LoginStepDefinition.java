package com.cg.selenium.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.selenium.bean.LoginBean;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinition {
	static WebDriver driver;

	LoginBean bean = new LoginBean();

	@Before
	public void page() {
		System.setProperty("webdriver.chrome.driver", "D:\\\\JENKINS\\\\Drivers\\\\chromedriver.exe");

	}

	@Given("^I have an account$")
	public void i_have_an_account() throws Throwable {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://localhost:7779/SeleniumTest/Login.html");
		
	}

	@When("^I enter valid username and valid password$")
	public void i_enter_valid_username_and_valid_password() throws Throwable {
		
		PageFactory.initElements(driver, bean);
		bean.setUserName("uday");
		bean.setPassWord("uday");

	}

	@When("^Click Submit$")
	public void click_Submit() throws Throwable {
		bean.submit();
	}

	@Then("^it should open my account$")
	public void it_should_open_my_account() throws Throwable {

		System.out.println("Account opened");
	}

	@After
	public void close() {
		driver.close();
	}

}
